package UnitTests;

import static org.junit.Assert.*;
import org.junit.Test;
import primitives.*;
import geometries.*;

public class CylinderTests 
{

	@Test
	public void testGetNormal()
	{
		
		
	}

}
